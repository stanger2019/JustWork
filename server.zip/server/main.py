import socket, threading

host = '192.168.0.7'
port = 2000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind((host, port))
print('Server launched')

class ClientThread(threading.Thread):
    def __init__(self, clientaddress, clientsocket):
        threading.Thread.__init__(self)
        self.csocket = clientsocket
        print("Новое подключение: ", clientaddress)

    def run(self):
        msg = ''
        while True:
            data = self.csocket.recv(4096)
            msg = data.decode()
            print(msg)


while True:
    server.listen(1)
    clientsocket, clientaddress = server.accept()
    newthread = ClientThread(clientaddress, clientsocket)
    newthread.start()

